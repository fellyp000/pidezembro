<?php
// Conectar ao banco de dados (substitua pelas suas credenciais)
$conn = new mysqli("localhost", "seu_usuario", "sua_senha", "seu_banco_de_dados");

// Verificar a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Lógica para armazenar o progresso do usuário no banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obter o ID do usuário da sessão
    $user_id = $_SESSION["user_id"];

    // Obter o estado das tarefas (concluído ou não)
    $task1 = isset($_POST["task1"]) ? 1 : 0;
    $task2 = isset($_POST["task2"]) ? 1 : 0;
    $task3 = isset($_POST["task3"]) ? 1 : 0;

    // Atualizar o progresso do usuário no banco de dados
    $sql = "UPDATE users SET task1 = $task1, task2 = $task2, task3 = $task3 WHERE id = $user_id";

    if ($conn->query($sql) === TRUE) {
        echo "Progresso atualizado com sucesso!";
    } else {
        echo "Erro ao atualizar o progresso: " . $conn->error;
    }
}

$conn->close();
?>